function saluer(prenom) {
  console.log("Bonjour " + prenom);
}
saluer("Nora");
saluer("Sami");
