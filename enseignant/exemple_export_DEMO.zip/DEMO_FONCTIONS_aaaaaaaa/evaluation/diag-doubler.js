function doubler(nombre) {
  return nombre * 2;
}
const scoreDouble = doubler(6);
console.log(scoreDouble);
