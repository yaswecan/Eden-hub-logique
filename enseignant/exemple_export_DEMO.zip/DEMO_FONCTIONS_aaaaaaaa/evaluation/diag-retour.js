function additionner(pommes, poires) {
  return pommes + poires;
}
const total = additionner(2, 3);
const totalSuivant = additionner(total, 4);
console.log(total);
console.log(totalSuivant);
