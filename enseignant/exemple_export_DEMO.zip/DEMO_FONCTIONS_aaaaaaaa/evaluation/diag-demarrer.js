function annoncerDepart() {
  console.log("La partie commence");
}
annoncerDepart();
