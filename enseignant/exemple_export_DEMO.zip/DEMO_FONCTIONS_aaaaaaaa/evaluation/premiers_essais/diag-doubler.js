function doubler(nombre) { console.log(nombre * 2); }
const scoreDouble = doubler(6);
console.log(scoreDouble);